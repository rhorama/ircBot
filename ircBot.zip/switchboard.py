import ircWeatherModule
import utils
def main(input):
    if len(input) == 0:
        return "error"
    elif input[0] != "!":
        return "error"
    elif input[1] == "w":
        if input[2] == "f":
            return ircWeatherModule.main(input[4:], True)
        else: 
            return ircWeatherModule.main(input[3:], False)
    elif str(input[1:3]) == "cf":
        return utils.flip()
    else:
        return "error"